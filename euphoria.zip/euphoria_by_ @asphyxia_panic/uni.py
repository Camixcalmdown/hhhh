import os
import sqlite3
import csv
import json
import threading
from googlesearch import search

GREEN = "\033[92m"
WHITE = "\033[97m"
RESET = "\033[0m"
RED = "\033[91m"

def print_frame(content, title=""):
    width = max(len(line) for line in content.split('\n')) + 8
    print(f"{RED}╔═{'═' * (width - 2)}═╗{RESET}")
    if title:
        print(f"{RED}║ {title.center(width - 4)} ║{RESET}")
    for line in content.split('\n'):
        print(f"{RED}║  {line.center(width - 4)} ║{RESET}")
    print(f"{RED}╚═{'═' * (width - 2)}═╝{RESET}")

def print_separator():
    print(f"{RED}{'═' * 80}{RESET}")

def get_size_of_directory(directory):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(directory):
        for file in filenames:
            file_path = os.path.join(dirpath, file)
            total_size += os.path.getsize(file_path)
    return total_size

def format_size(size):
    for unit in ['Б', 'КБ', 'МБ', 'ГБ']:
        if size < 1024:
            return f"{size:.2f} {unit}"
        size /= 1024
    return f"{size:.2f} ТБ"

def search_in_sqlite(db_path, search_term):
    found_count = 0
    try:
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("PRAGMA case_sensitive_like = TRUE")
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = cursor.fetchall()
            for table_name in tables:
                cursor.execute(f"SELECT * FROM {table_name[0]};")
                rows = cursor.fetchall()
                headers = [description[0] for description in cursor.description]
                found = False
                for row in rows:
                    if any(search_term in str(cell) for cell in row):
                        if not found:
                            header_text = f"📂 SQLite: {os.path.basename(db_path)} | Таблица: {table_name[0]}"
                            print_frame(header_text)
                            found = True
                        row_text = "\n".join([f"    [{RED}{headers[i]}{RESET}]: {cell}" for i, cell in enumerate(row)])
                        print(f"{RED}    [+] {row_text}{RESET}")
                        found_count += 1
                if found:
                    print_separator()
    except sqlite3.Error:
        pass
    return found_count

def search_in_csv(file_path, search_term):
    found_count = 0
    try:
        with open(file_path, mode='r', encoding='utf-8', errors='ignore') as file:
            reader = csv.DictReader(file, delimiter=';')
            found = False
            for row in reader:
                if any(search_term in str(value) for value in row.values()):
                    if not found:
                        header_text = f"📄 CSV: {os.path.basename(file_path)}"
                        print_frame(header_text)
                        found = True
                    row_text = "\n".join([f"    [{RED}{key.capitalize()}{RESET}]: {value}" for key, value in row.items()])
                    print(f"{RED}    [+] {row_text}{RESET}")
                    found_count += 1
            if found:
                print_separator()
    except (FileNotFoundError, IOError):
        pass
    return found_count

def search_in_json(file_path, search_term):
    found_count = 0
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
            data = json.load(file)

            def search_recursive(d):
                nonlocal found_count
                if isinstance(d, dict):
                    found = False
                    for key, value in d.items():
                        if search_term in str(value):
                            if not found:
                                header_text = f"📊 JSON: {os.path.basename(file_path)}"
                                print_frame(header_text)
                                found = True
                            print(f"{RED}    [+] [{key}]: {value}{RESET}")
                            found_count += 1
                        search_recursive(value)
                elif isinstance(d, list):
                    for item in d:
                        search_recursive(item)

            search_recursive(data)
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    return found_count

def search_in_txt(file_path, search_term):
    found_count = 0
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
            found = False
            for line in file:
                if search_term in line:
                    if not found:
                        header_text = f"📝 TXT: {os.path.basename(file_path)}"
                        print_frame(header_text)
                        found = True
                    print(f"{RED}    [+] {line.strip()}{RESET}")
                    found_count += 1
            if found:
                print_separator()
    except (FileNotFoundError, IOError):
        pass
    return found_count

def search_google(search_term):
    found_count = 0
    header_text = f"🔍 НАЙДЕННЫЕ ССЫЛКИ В БАЗЕ: {search_term}"
    print_frame(header_text)
    for url in search(search_term, num_results=10):
        print(f"{RED}    [+] {url}{RESET}")
        found_count += 1
    print_separator()
    return found_count

def search_databases(directory, search_term):
    if not os.path.isdir(directory):
        return 0

    total_found = 0
    threads = []
    lock = threading.Lock()

    def search_file(filename):
        nonlocal total_found
        file_path = os.path.join(directory, filename)
        if os.path.isfile(file_path):
            found = 0
            if filename.endswith('.db'):
                found = search_in_sqlite(file_path, search_term)
            elif filename.endswith('.csv'):
                found = search_in_csv(file_path, search_term)
            elif filename.endswith('.json'):
                found = search_in_json(file_path, search_term)
            elif filename.endswith('.txt'):
                found = search_in_txt(file_path, search_term)
            
            with lock:
                total_found += found

    for filename in os.listdir(directory):
        thread = threading.Thread(target=search_file, args=(filename,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()
    
    return total_found

def main():
    directory = 'base'
    search_term = input("Введите поисковой запрос: ").strip()

    if not search_term:
        print(f"{RED}Поисковой запрос не может быть пустым.{RESET}")
        return

    total_found = search_databases(directory, search_term)
    total_google_found = search_google(search_term)

    print_separator()
    print(f"{RED}🔍 Найдено записей в базах данных: {total_found}{RESET}")
    print(f"{RED}🔍 Найдено записей в ССЫЛОК: {total_google_found}{RESET}")
    print(f"{RED}📦 Общий размер базы данных: {format_size(get_size_of_directory(directory))}{RESET}")
    print_separator()

if __name__ == "__main__":
    main()
