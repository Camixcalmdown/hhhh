import os
import csv
import pyfiglet
import xlrd
from openpyxl import load_workbook
from colorama import init, Fore, Style
from pystyle import *
import random
import time              
import requests
from fake_useragent import UserAgent
import subprocess
from colorama import Fore, Style
import colorama

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_console()

print(Colorate.Horizontal(Colors.red_to_blue, (""" 
                                     



             ███▄    █ ▓█████▄▄▄█████▓ █     █░ ▒█████   ██▀███   ██ ▄█▀    ██▓███   ██▀███   ▒█████  ▄▄▄█████▓ ▒█████   ▄████▄   ▒█████   ██▓      ██████ 
             ██ ▀█   █ ▓█   ▀▓  ██▒ ▓▒▓█░ █ ░█░▒██▒  ██▒▓██ ▒ ██▒ ██▄█▒    ▓██░  ██▒▓██ ▒ ██▒▒██▒  ██▒▓  ██▒ ▓▒▒██▒  ██▒▒██▀ ▀█  ▒██▒  ██▒▓██▒    ▒██    ▒ 
            ▓██  ▀█ ██▒▒███  ▒ ▓██░ ▒░▒█░ █ ░█ ▒██░  ██▒▓██ ░▄█ ▒▓███▄░    ▓██░ ██▓▒▓██ ░▄█ ▒▒██░  ██▒▒ ▓██░ ▒░▒██░  ██▒▒▓█    ▄ ▒██░  ██▒▒██░    ░ ▓██▄   
            ▓██▒  ▐▌██▒▒▓█  ▄░ ▓██▓ ░ ░█░ █ ░█ ▒██   ██░▒██▀▀█▄  ▓██ █▄    ▒██▄█▓▒ ▒▒██▀▀█▄  ▒██   ██░░ ▓██▓ ░ ▒██   ██░▒▓▓▄ ▄██▒▒██   ██░▒██░      ▒   ██▒
            ▒██░   ▓██░░▒████▒ ▒██▒ ░ ░░██▒██▓ ░ ████▓▒░░██▓ ▒██▒▒██▒ █▄   ▒██▒ ░  ░░██▓ ▒██▒░ ████▓▒░  ▒██▒ ░ ░ ████▓▒░▒ ▓███▀ ░░ ████▓▒░░██████▒▒██████▒▒
            ░ ▒░   ▒ ▒ ░░ ▒░ ░ ▒ ░░   ░ ▓░▒ ▒  ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░▒ ▒▒ ▓▒   ▒▓▒░ ░  ░░ ▒▓ ░▒▓░░ ▒░▒░▒░   ▒ ░░   ░ ▒░▒░▒░ ░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒░▓  ░▒ ▒▓▒ ▒ ░
            ░ ░░   ░ ▒░ ░ ░  ░   ░      ▒ ░ ░    ░ ▒ ▒░   ░▒ ░ ▒░░ ░▒ ▒░   ░▒ ░       ░▒ ░ ▒░  ░ ▒ ▒░     ░      ░ ▒ ▒░   ░  ▒     ░ ▒ ▒░ ░ ░ ▒  ░░ ░▒  ░ ░
               ░   ░ ░    ░    ░        ░   ░  ░ ░ ░ ▒    ░░   ░ ░ ░░ ░    ░░         ░░   ░ ░ ░ ░ ▒    ░      ░ ░ ░ ▒  ░        ░ ░ ░ ▒    ░ ░   ░  ░  ░  
                     ░    ░  ░            ░        ░ ░     ░     ░  ░                  ░         ░ ░               ░ ░  ░ ░          ░ ░      ░  ░      ░  
                                                                                                                        ░                                  

                                                        ⌈─────────────────────|─────────────────────────⌉
                                                        │tgc: @xwondedperehod |creator: @asphyxia_panic │
                                                        ⌊─────────────────────|─────────────────────────⌋                   

                                                              ┌─────────────────────────────┐    
                                                              │[1]          DDos            │
                                                              │-----------------------------│    
                                                              │[2]         bomder           │    
                                                              │-----------------------------│    
                                                              │[3]        webcrawler        │    
                                                              └─────────────────────────────┘    
    """))) 

    

    
choice = input(Fore.RED + "                                            Выберите номер функции ('q' для выхода в меню) : " + Style.RESET_ALL)

if choice.lower() == "q":
    os.system("python main.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "1":
    os.system("python DDos1.py")  # Замените 'file1.py' на имя вашего файла

if choice.lower() == "2":
    os.system("python bomber.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "3":
    os.system("python webcrawler.py")  # Замените 'file1.py' на имя вашего файла