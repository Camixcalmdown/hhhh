import os
import csv
import pyfiglet
import xlrd
from openpyxl import load_workbook
from colorama import init, Fore, Style
from pystyle import *
import random
import time              
import requests
from fake_useragent import UserAgent
import subprocess
from colorama import Fore, Style
import colorama

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_console()

print(Colorate.Horizontal(Colors.red_to_blue, (""" 
                                     
                                     
                                     
                                     

                                       ▄████ ▓█████  ███▄    █ ▓█████  ██▀███   ▄▄▄     ▄▄▄█████▓ ▒█████   ██▀███    ██████ 
                                      ██▒ ▀█▒▓█   ▀  ██ ▀█   █ ▓█   ▀ ▓██ ▒ ██▒▒████▄   ▓  ██▒ ▓▒▒██▒  ██▒▓██ ▒ ██▒▒██    ▒ 
                                     ▒██░▄▄▄░▒███   ▓██  ▀█ ██▒▒███   ▓██ ░▄█ ▒▒██  ▀█▄ ▒ ▓██░ ▒░▒██░  ██▒▓██ ░▄█ ▒░ ▓██▄   
                                      ░▓█  ██▓▒▓█  ▄ ▓██▒  ▐▌██▒▒▓█  ▄ ▒██▀▀█▄  ░██▄▄▄▄██░ ▓██▓ ░ ▒██   ██░▒██▀▀█▄    ▒   ██▒
                                     ░▒▓███▀▒░▒████▒▒██░   ▓██░░▒████▒░██▓ ▒██▒ ▓█   ▓██▒ ▒██▒ ░ ░ ████▓▒░░██▓ ▒██▒▒██████▒▒
                                      ░▒   ▒ ░░ ▒░ ░░ ▒░   ▒ ▒ ░░ ▒░ ░░ ▒▓ ░▒▓░ ▒▒   ▓▒█░ ▒ ░░   ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░▒ ▒▓▒ ▒ ░
                                       ░   ░  ░ ░  ░░ ░░   ░ ▒░ ░ ░  ░  ░▒ ░ ▒░  ▒   ▒▒ ░   ░      ░ ▒ ▒░   ░▒ ░ ▒░░ ░▒  ░ ░
                                     ░ ░   ░    ░      ░   ░ ░    ░     ░░   ░   ░   ▒    ░      ░ ░ ░ ▒    ░░   ░ ░  ░  ░  
                                           ░    ░  ░         ░    ░  ░   ░           ░  ░            ░ ░     ░           ░  
                                                                                       
                                                        ⌈─────────────────────|─────────────────────────⌉
                                                        │tgc: @xwondedperehod |creator: @asphyxia_panic │
                                                        ⌊─────────────────────|─────────────────────────⌋                   

                                                              ┌─────────────────────────────┐    
                                                              │[1]    generator emain       │
                                                              │-----------------------------│    
                                                              │[2] russian number generator │    
                                                              │-----------------------------│    
                                                              │[3]      generator IP        │    
                                                              │-----------------------------│ 
                                                              │[4]    generator snils       │
                                                              │-----------------------------│ 
                                                              │[5]    generator password    │
                                                              │-----------------------------│ 
                                                              │[6]     generator inn        │                               
                                                              │-----------------------------│
                                                              │[7]    insult generator      │ 
                                                              │-----------------------------│
                                                              │[8] censorship of the text   │        
                                                              └─────────────────────────────┘    
    """))) 

    

    
choice = input(Fore.RED + "                                            Выберите номер функции ('q' для выхода в меню) : " + Style.RESET_ALL)

if choice.lower() == "q":
    os.system("python main.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "1":
    os.system("python genmail.py")  # Замените 'file1.py' на имя вашего файла

if choice.lower() == "2":
    os.system("python genruss.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "3":
    os.system("python genip.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "4":
    os.system("python gensnils.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "5":
    os.system("python genpasswd.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "6":
    os.system("python geninn.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "7":
    os.system("python gentroll.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "8":
    os.system("python swat.py")  # Замените 'file1.py' на имя вашего файла